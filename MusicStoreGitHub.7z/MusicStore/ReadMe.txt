1.You need to copy 17032(database) in your D:\Program Files\PostgreSQL\9.5\data\base directory.
2.Open your PostgreSql PGadmin and run MusicStoreOfficialQuery1 file.
3.Open the project in Visual Studio and change NpgSqlConnection object with your own User and Password.
4.Put your own music by Admin Panel which you can access by ur creating account with Admin username.
5.Enjoy :)